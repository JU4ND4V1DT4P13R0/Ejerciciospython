ciudades = ['medellin','bogota','ibague','cali']
print('Ciudades loop:')
for x in ciudades:
    print('Ciudad: ' + x)