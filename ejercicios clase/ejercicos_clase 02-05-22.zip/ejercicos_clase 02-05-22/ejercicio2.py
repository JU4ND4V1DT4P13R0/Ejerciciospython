a=[]
n=int(input("dijite el valor limite de la lista"))
for i in range(n):
    a.append(n**3)
print(a)
