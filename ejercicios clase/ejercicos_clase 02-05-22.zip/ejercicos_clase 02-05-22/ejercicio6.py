v=[]
limite=int(input("dijite el numero limite de tu lista:"))
for i in range (limite):
    valores=int(input("dijite los valores"))
    v.append(valores**2)
print(v)
