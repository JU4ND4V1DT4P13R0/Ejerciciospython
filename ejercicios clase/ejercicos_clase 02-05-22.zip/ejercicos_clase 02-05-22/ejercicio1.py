import math
a=[1,2,3,4,5,]
c=[]
for i in a:
    c.append(math.sqrt(i))
    print (c)